using MySql.Data.MySqlClient;

namespace EventScheduler;

public partial class CoordinateMeetingForm : Form
{
    public CoordinateMeetingForm()
    {
        InitializeComponent();
        LoadEmployees();
    }

    private void LoadEmployees()
    {
        try
        {
            clbEmployees.Items.Clear();
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT id, emailAddress FROM Employee ORDER BY emailAddress", conn);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                clbEmployees.Items.Add(new EmpItem { Id = Convert.ToInt32(r["id"]), Name = r["emailAddress"].ToString()! });
        }
        catch { }
    }

    private void btnSend_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtTitle.Text))
        { MessageBox.Show("Meeting title is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        if (clbEmployees.CheckedItems.Count == 0)
        { MessageBox.Show("Select at least one team member.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

        int dur = int.TryParse(txtDuration.Text, out int d) ? d : 60;
        var start = dtpDate.Value.Date + dtpStartTime.Value.TimeOfDay;
        var end = start.AddMinutes(dur);

        try
        {
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            foreach (EmpItem emp in clbEmployees.CheckedItems)
            {
                string sql = @"INSERT INTO Event (title,description,startTime,endTime,duration,location,attendees,attendeeID)
                               VALUES (@t,@d,@s,@e,@dur,@l,@a,@eid)";
                using var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@t", txtTitle.Text.Trim());
                cmd.Parameters.AddWithValue("@d", txtNotes.Text.Trim());
                cmd.Parameters.AddWithValue("@s", start);
                cmd.Parameters.AddWithValue("@e", end);
                cmd.Parameters.AddWithValue("@dur", dur);
                cmd.Parameters.AddWithValue("@l", txtLocation.Text.Trim());
                cmd.Parameters.AddWithValue("@a", clbEmployees.CheckedItems.Count);
                cmd.Parameters.AddWithValue("@eid", emp.Id);
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show($"Meeting scheduled for {clbEmployees.CheckedItems.Count} member(s)!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnCancel_Click(object sender, EventArgs e) => this.Close();
}

public class EmpItem
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public override string ToString() => Name;
}
