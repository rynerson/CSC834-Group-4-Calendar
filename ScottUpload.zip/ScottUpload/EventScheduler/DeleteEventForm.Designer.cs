namespace EventScheduler;

partial class DeleteEventForm
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.Text = "EventScheduler — Delete Event";
        this.Size = new Size(500, 310);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(212, 208, 200);

        var menu = new MenuStrip { BackColor = Color.FromArgb(212, 208, 200) };
        menu.Items.Add("File"); menu.Items.Add("Edit");
        menu.Items.Add("View"); menu.Items.Add("Help");
        this.MainMenuStrip = menu;

        statusBar = new StatusStrip { BackColor = Color.FromArgb(212, 208, 200) };
        statusBar.Items.Add(new ToolStripStatusLabel("Confirm deletion of selected event."));

        // Event detail panel
        var pnlDetail = new Panel
        {
            Location = new Point(12, 32),
            Size = new Size(462, 95),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White
        };

        int lx = 15, vx = 80, y = 12, gap = 26;
        pnlDetail.Controls.Add(BL("Title:", lx, y));
        lblTitle = VL(vx, y, 360); pnlDetail.Controls.Add(lblTitle); y += gap;
        pnlDetail.Controls.Add(BL("Date:", lx, y));
        lblDate = VL(vx, y, 360); pnlDetail.Controls.Add(lblDate); y += gap;
        pnlDetail.Controls.Add(BL("Location:", lx, y));
        lblLocation = VL(vx, y, 360); pnlDetail.Controls.Add(lblLocation);

        // Warning panel
        var pnlWarning = new Panel
        {
            Location = new Point(12, 138),
            Size = new Size(462, 40),
            BackColor = Color.FromArgb(255, 255, 204),
            BorderStyle = BorderStyle.FixedSingle
        };
        var lblWarnIcon = new Label { Text = "⚠", Location = new Point(10, 10), AutoSize = true, Font = new Font("Segoe UI", 10) };
        var lblWarn = new Label
        {
            Text = "Are you sure you want to delete this event? This action cannot be undone.",
            Location = new Point(35, 12),
            Width = 415,
            Font = new Font("Segoe UI", 9)
        };
        pnlWarning.Controls.AddRange(new Control[] { lblWarnIcon, lblWarn });

        // Buttons
        btnDelete = new Button
        {
            Text = "Delete",
            Location = new Point(333, 192),
            Size = new Size(65, 25),
            BackColor = Color.FromArgb(180, 30, 30),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat
        };
        btnCancel = new Button { Text = "Cancel", Location = new Point(408, 192), Size = new Size(65, 25) };
        btnDelete.Click += btnDelete_Click;
        btnCancel.Click += btnCancel_Click;

        this.Controls.AddRange(new Control[] { menu, pnlDetail, pnlWarning, btnDelete, btnCancel, statusBar });
    }

    private Label BL(string t, int x, int y) =>
        new Label { Text = t, Location = new Point(x, y), AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
    private Label VL(int x, int y, int w) =>
        new Label { Text = "", Location = new Point(x, y), Width = w, Font = new Font("Segoe UI", 9) };

    private Label lblTitle, lblDate, lblLocation;
    private Button btnDelete, btnCancel;
    private StatusStrip statusBar;
}
