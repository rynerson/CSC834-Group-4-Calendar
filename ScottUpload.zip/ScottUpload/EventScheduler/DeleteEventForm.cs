using MySql.Data.MySqlClient;

namespace EventScheduler;

public partial class DeleteEventForm : Form
{
    private int _eventId;

    public DeleteEventForm(int eventId = -1)
    {
        InitializeComponent();
        _eventId = eventId;
        if (eventId > 0) LoadEvent(eventId);
    }

    private void LoadEvent(int id)
    {
        try
        {
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Event WHERE eventID=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var r = cmd.ExecuteReader();
            if (r.Read())
            {
                lblTitle.Text = r["title"].ToString();
                lblDate.Text = Convert.ToDateTime(r["startTime"]).ToString("MM/dd/yyyy");
                lblLocation.Text = r["location"].ToString();
                _eventId = id;
            }
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (_eventId <= 0)
        { MessageBox.Show("No event selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

        try
        {
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("DELETE FROM Event WHERE eventID=@id", conn);
            cmd.Parameters.AddWithValue("@id", _eventId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Event deleted.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnCancel_Click(object sender, EventArgs e) => this.Close();
}
