namespace EventScheduler;

partial class CoordinateMeetingForm
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.Text = "EventScheduler — Coordinate Meeting for Team Members";
        this.Size = new Size(500, 480);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(212, 208, 200);

        var menu = new MenuStrip { BackColor = Color.FromArgb(212, 208, 200) };
        menu.Items.Add("File"); menu.Items.Add("Edit");
        menu.Items.Add("View"); menu.Items.Add("Help");
        this.MainMenuStrip = menu;

        statusBar = new StatusStrip { BackColor = Color.FromArgb(212, 208, 200) };
        statusBar.Items.Add(new ToolStripStatusLabel("Manager view — select team members and propose a meeting time."));

        int y = 32, col1 = 15, col2 = 258, gap = 48;

        var lblTitle = L("Meeting Title:", col1, y); y += 18;
        txtTitle = T(col1, y, 463); y += gap;

        var lblPD = L("Proposed Date:", col1, y);
        var lblLoc = L("Location:", col2, y); y += 18;
        dtpDate = new DateTimePicker { Location = new Point(col1, y), Width = 225, Format = DateTimePickerFormat.Custom, CustomFormat = "MM/dd/yyyy" };
        txtLocation = T(col2, y, 225); y += gap;

        var lblST = L("Start Time:", col1, y);
        var lblDur = L("Duration (mins):", col2, y); y += 18;
        dtpStartTime = new DateTimePicker { Location = new Point(col1, y), Width = 225, Format = DateTimePickerFormat.Time, ShowUpDown = true };
        txtDuration = T(col2, y, 225); y += gap;

        var lblMembers = L("Select Team Members:", col1, y); y += 18;
        clbEmployees = new CheckedListBox
        {
            Location = new Point(col1, y),
            Size = new Size(463, 90),
            Font = new Font("Segoe UI", 9)
        }; y += 100;

        var lblNotes = L("Agenda / Notes:", col1, y); y += 18;
        txtNotes = new TextBox
        {
            Location = new Point(col1, y),
            Width = 463,
            Height = 55,
            Multiline = true,
            ScrollBars = ScrollBars.Vertical
        }; y += 65;

        btnSend = new Button { Text = "Send Invites", Location = new Point(320, y), Size = new Size(90, 25) };
        btnCancel = new Button { Text = "Cancel", Location = new Point(418, y), Size = new Size(65, 25) };
        btnSend.Click += btnSend_Click;
        btnCancel.Click += btnCancel_Click;

        this.Controls.AddRange(new Control[] {
            menu,
            lblTitle, txtTitle,
            lblPD, dtpDate, lblLoc, txtLocation,
            lblST, dtpStartTime, lblDur, txtDuration,
            lblMembers, clbEmployees,
            lblNotes, txtNotes,
            btnSend, btnCancel, statusBar
        });
    }

    private Label L(string t, int x, int y) => new Label { Text = t, Location = new Point(x, y), AutoSize = true };
    private TextBox T(int x, int y, int w) => new TextBox { Location = new Point(x, y), Width = w };

    private TextBox txtTitle, txtLocation, txtDuration, txtNotes;
    private DateTimePicker dtpDate, dtpStartTime;
    private CheckedListBox clbEmployees;
    private Button btnSend, btnCancel;
    private StatusStrip statusBar;
}
