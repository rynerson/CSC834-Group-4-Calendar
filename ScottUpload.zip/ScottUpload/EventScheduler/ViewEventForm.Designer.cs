namespace EventScheduler;

partial class ViewEventForm
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.Text = "EventScheduler — View Event";
        this.Size = new Size(500, 340);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(212, 208, 200);

        var menu = new MenuStrip { BackColor = Color.FromArgb(212, 208, 200) };
        menu.Items.Add("File"); menu.Items.Add("Edit");
        menu.Items.Add("View"); menu.Items.Add("Help");
        this.MainMenuStrip = menu;

        statusBar = new StatusStrip { BackColor = Color.FromArgb(212, 208, 200) };
        statusBar.Items.Add(new ToolStripStatusLabel("Viewing event details."));

        // Detail panel with border
        pnlDetail = new Panel
        {
            Location = new Point(12, 32),
            Size = new Size(462, 210),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White
        };

        int lx = 15, vx = 120, y = 15, gap = 28;

        pnlDetail.Controls.Add(MakeBoldLabel("Title:", lx, y));
        lblTitle = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblTitle); y += gap;

        pnlDetail.Controls.Add(MakeBoldLabel("Location:", lx, y));
        lblLocation = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblLocation); y += gap;

        pnlDetail.Controls.Add(MakeBoldLabel("Start:", lx, y));
        lblStart = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblStart); y += gap;

        pnlDetail.Controls.Add(MakeBoldLabel("End:", lx, y));
        lblEnd = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblEnd); y += gap;

        pnlDetail.Controls.Add(MakeBoldLabel("Duration:", lx, y));
        lblDuration = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblDuration); y += gap;

        pnlDetail.Controls.Add(MakeBoldLabel("Attendees:", lx, y));
        lblAttendees = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblAttendees); y += gap;

        pnlDetail.Controls.Add(MakeBoldLabel("Description:", lx, y));
        lblDescription = MakeValueLabel(vx, y, 320); pnlDetail.Controls.Add(lblDescription);

        // Buttons
        btnEdit = new Button { Text = "Edit", Location = new Point(340, 255), Size = new Size(65, 25) };
        btnClose = new Button { Text = "Close", Location = new Point(413, 255), Size = new Size(65, 25) };
        btnEdit.Click += btnEdit_Click;
        btnClose.Click += btnClose_Click;

        this.Controls.AddRange(new Control[] { menu, pnlDetail, btnEdit, btnClose, statusBar });
    }

    private Label MakeBoldLabel(string text, int x, int y) =>
        new Label { Text = text, Location = new Point(x, y), AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold) };

    private Label MakeValueLabel(int x, int y, int w) =>
        new Label { Text = "", Location = new Point(x, y), Width = w, Font = new Font("Segoe UI", 9) };

    private Panel pnlDetail;
    private Label lblTitle, lblLocation, lblStart, lblEnd, lblDuration, lblAttendees, lblDescription;
    private Button btnEdit, btnClose;
    private StatusStrip statusBar;
}
