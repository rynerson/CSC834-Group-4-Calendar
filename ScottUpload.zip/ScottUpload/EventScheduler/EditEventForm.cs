using MySql.Data.MySqlClient;

namespace EventScheduler;

public partial class EditEventForm : Form
{
    private int _eventId;

    public EditEventForm(int eventId = -1)
    {
        InitializeComponent();
        _eventId = eventId;
        if (eventId > 0) LoadEvent(eventId);
    }

    private void LoadEvent(int id)
    {
        try
        {
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Event WHERE eventID=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var r = cmd.ExecuteReader();
            if (r.Read())
            {
                txtTitle.Text = r["title"].ToString();
                txtLocation.Text = r["location"].ToString();
                var start = Convert.ToDateTime(r["startTime"]);
                var end = Convert.ToDateTime(r["endTime"]);
                dtpStartDate.Value = start.Date;
                dtpStartTime.Value = start;
                dtpEndDate.Value = end.Date;
                dtpEndTime.Value = end;
                txtDuration.Text = r["duration"].ToString();
                txtAttendees.Text = r["attendees"].ToString();
                txtDescription.Text = r["description"].ToString();
            }
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtTitle.Text))
        { MessageBox.Show("Title is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

        var start = dtpStartDate.Value.Date + dtpStartTime.Value.TimeOfDay;
        var end = dtpEndDate.Value.Date + dtpEndTime.Value.TimeOfDay;
        if (end <= start)
        { MessageBox.Show("End must be after Start.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

        try
        {
            int duration = (int)(end - start).TotalMinutes;
            int attendees = int.TryParse(txtAttendees.Text, out int a) ? a : 0;

            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            string sql = @"UPDATE Event SET title=@t,description=@d,startTime=@s,endTime=@e,
                           duration=@dur,location=@l,attendees=@a WHERE eventID=@id";
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@t", txtTitle.Text.Trim());
            cmd.Parameters.AddWithValue("@d", txtDescription.Text.Trim());
            cmd.Parameters.AddWithValue("@s", start);
            cmd.Parameters.AddWithValue("@e", end);
            cmd.Parameters.AddWithValue("@dur", duration);
            cmd.Parameters.AddWithValue("@l", txtLocation.Text.Trim());
            cmd.Parameters.AddWithValue("@a", attendees);
            cmd.Parameters.AddWithValue("@id", _eventId);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Event updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnCancel_Click(object sender, EventArgs e) => this.Close();
}
