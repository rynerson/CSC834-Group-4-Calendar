using MySql.Data.MySqlClient;

namespace EventScheduler;

public partial class ViewEventForm : Form
{
    private int _eventId;

    public ViewEventForm(int eventId = -1)
    {
        InitializeComponent();
        _eventId = eventId;
        if (eventId > 0) LoadEvent(eventId);
    }

    private void LoadEvent(int id)
    {
        try
        {
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Event WHERE eventID=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var r = cmd.ExecuteReader();
            if (r.Read())
            {
                lblTitle.Text = r["title"].ToString();
                lblLocation.Text = r["location"].ToString();
                lblStart.Text = Convert.ToDateTime(r["startTime"]).ToString("MM/dd/yyyy h:mm tt");
                lblEnd.Text = Convert.ToDateTime(r["endTime"]).ToString("MM/dd/yyyy h:mm tt");
                lblDuration.Text = $"{r["duration"]} minutes";
                lblAttendees.Text = r["attendees"].ToString();
                lblDescription.Text = r["description"].ToString();
                _eventId = id;
            }
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnEdit_Click(object sender, EventArgs e)
    {
        if (_eventId > 0)
        {
            new EditEventForm(_eventId).ShowDialog();
            LoadEvent(_eventId);
        }
    }

    private void btnClose_Click(object sender, EventArgs e) => this.Close();
}
