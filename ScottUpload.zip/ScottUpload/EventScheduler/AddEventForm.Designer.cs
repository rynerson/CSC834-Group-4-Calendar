namespace EventScheduler;

partial class AddEventForm
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.Text = "EventScheduler — Add Event";
        this.Size = new Size(500, 430);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(212, 208, 200);

        var menu = new MenuStrip { BackColor = Color.FromArgb(212, 208, 200) };
        menu.Items.Add("File"); menu.Items.Add("Edit");
        menu.Items.Add("View"); menu.Items.Add("Help");
        this.MainMenuStrip = menu;

        statusBar = new StatusStrip { BackColor = Color.FromArgb(212, 208, 200) };
        statusLabel = new ToolStripStatusLabel("Enter event details and click Save.");
        statusBar.Items.Add(statusLabel);

        int col1 = 15, col2 = 258, y = 32, gap = 48;

        var lblTitle = L("Title:", col1, y);
        var lblLoc = L("Location:", col2, y); y += 18;
        txtTitle = T(col1, y, 225); txtLocation = T(col2, y, 225); y += gap;

        var lblSD = L("Start Date:", col1, y);
        var lblST = L("Start Time:", col2, y); y += 18;
        dtpStartDate = DP(col1, y, "MM/dd/yyyy", false);
        dtpStartTime = DPTime(col2, y); y += gap;

        var lblED = L("End Date:", col1, y);
        var lblET = L("End Time:", col2, y); y += 18;
        dtpEndDate = DP(col1, y, "MM/dd/yyyy", false);
        dtpEndTime = DPTime(col2, y);
        dtpEndTime.Value = DateTime.Now.AddHours(1); y += gap;

        var lblDur = L("Duration (mins):", col1, y);
        var lblAtt = L("Attendees:", col2, y); y += 18;
        txtDuration = T(col1, y, 225); txtDuration.ReadOnly = true;
        txtAttendees = T(col2, y, 225); y += gap;

        var lblDesc = L("Description:", col1, y); y += 18;
        txtDescription = new TextBox { Location = new Point(col1, y), Width = 463, Height = 60, Multiline = true, ScrollBars = ScrollBars.Vertical }; y += 68;

        btnSave = new Button { Text = "Save", Location = new Point(340, y), Size = new Size(65, 25) };
        btnCancel = new Button { Text = "Cancel", Location = new Point(413, y), Size = new Size(65, 25) };
        btnSave.Click += btnSave_Click;
        btnCancel.Click += btnCancel_Click;

        dtpStartDate.ValueChanged += (s, e) => CalcDuration();
        dtpStartTime.ValueChanged += (s, e) => CalcDuration();
        dtpEndDate.ValueChanged += (s, e) => CalcDuration();
        dtpEndTime.ValueChanged += (s, e) => CalcDuration();

        this.Controls.AddRange(new Control[] {
            menu,
            lblTitle, txtTitle, lblLoc, txtLocation,
            lblSD, dtpStartDate, lblST, dtpStartTime,
            lblED, dtpEndDate, lblET, dtpEndTime,
            lblDur, txtDuration, lblAtt, txtAttendees,
            lblDesc, txtDescription,
            btnSave, btnCancel, statusBar
        });
    }

    private void CalcDuration()
    {
        try
        {
            var start = dtpStartDate.Value.Date + dtpStartTime.Value.TimeOfDay;
            var end = dtpEndDate.Value.Date + dtpEndTime.Value.TimeOfDay;
            int m = (int)(end - start).TotalMinutes;
            txtDuration.Text = m > 0 ? m.ToString() : "";
        }
        catch { }
    }

    private Label L(string t, int x, int y) => new Label { Text = t, Location = new Point(x, y), AutoSize = true };
    private TextBox T(int x, int y, int w) => new TextBox { Location = new Point(x, y), Width = w };
    private DateTimePicker DP(int x, int y, string fmt, bool updown) =>
        new DateTimePicker { Location = new Point(x, y), Width = 225, Format = DateTimePickerFormat.Custom, CustomFormat = fmt, ShowUpDown = updown };
    private DateTimePicker DPTime(int x, int y) =>
        new DateTimePicker { Location = new Point(x, y), Width = 225, Format = DateTimePickerFormat.Time, ShowUpDown = true };

    private TextBox txtTitle, txtLocation, txtDuration, txtAttendees, txtDescription;
    private DateTimePicker dtpStartDate, dtpStartTime, dtpEndDate, dtpEndTime;
    private Button btnSave, btnCancel;
    private StatusStrip statusBar;
    private ToolStripStatusLabel statusLabel;
}
