namespace EventScheduler;

public class Employee
{
    public int Id { get; set; }
    public string EmailAddress { get; set; } = string.Empty;
}
