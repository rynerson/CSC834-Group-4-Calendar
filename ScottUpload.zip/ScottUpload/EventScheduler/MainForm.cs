namespace EventScheduler;

public partial class MainForm : Form
{
    public MainForm()
    {
        InitializeComponent();
    }

    private void btnAddEvent_Click(object sender, EventArgs e)
    {
        new AddEventForm().ShowDialog();
    }

    private void btnViewEvent_Click(object sender, EventArgs e)
    {
        new ViewEventForm().ShowDialog();
    }

    private void btnEditEvent_Click(object sender, EventArgs e)
    {
        new EditEventForm().ShowDialog();
    }

    private void btnDeleteEvent_Click(object sender, EventArgs e)
    {
        new DeleteEventForm().ShowDialog();
    }

    private void btnViewByMonth_Click(object sender, EventArgs e)
    {
        new ViewByMonthForm().ShowDialog();
    }

    private void btnCoordinateMeeting_Click(object sender, EventArgs e)
    {
        new CoordinateMeetingForm().ShowDialog();
    }
}
