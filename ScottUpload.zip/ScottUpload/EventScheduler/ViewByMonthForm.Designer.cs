namespace EventScheduler;

partial class ViewByMonthForm
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.Text = "EventScheduler — View Events by Month";
        this.Size = new Size(560, 480);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(212, 208, 200);

        var menu = new MenuStrip { BackColor = Color.FromArgb(212, 208, 200) };
        menu.Items.Add("File"); menu.Items.Add("Edit");
        menu.Items.Add("View"); menu.Items.Add("Help");
        this.MainMenuStrip = menu;

        statusBar = new StatusStrip { BackColor = Color.FromArgb(212, 208, 200) };
        statusBar.Items.Add(new ToolStripStatusLabel("Click an event to view details."));

        // Navigation row
        btnPrev = new Button { Text = "◄ Prev", Location = new Point(12, 32), Size = new Size(70, 25) };
        lblMonthYear = new Label
        {
            Text = "",
            Location = new Point(90, 36),
            Width = 360,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 11, FontStyle.Bold)
        };
        btnNext = new Button { Text = "Next ►", Location = new Point(468, 32), Size = new Size(70, 25) };

        btnPrev.Click += btnPrev_Click;
        btnNext.Click += btnNext_Click;

        // Calendar panel
        calendarPanel = new Panel
        {
            Location = new Point(12, 62),
            Size = new Size(526, 360),
            BorderStyle = BorderStyle.FixedSingle
        };

        this.Controls.AddRange(new Control[] { menu, btnPrev, lblMonthYear, btnNext, calendarPanel, statusBar });
    }

    private Button btnPrev, btnNext;
    private Label lblMonthYear;
    private Panel calendarPanel;
    private StatusStrip statusBar;
}
