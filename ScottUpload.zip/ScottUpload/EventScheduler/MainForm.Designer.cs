namespace EventScheduler;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.Text = "EventScheduler - Main Menu";
        this.Size = new Size(420, 380);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(240, 240, 240);

        var lblTitle = new Label
        {
            Text = "EventScheduler",
            Font = new Font("Segoe UI", 16, FontStyle.Bold),
            ForeColor = Color.FromArgb(0, 70, 127),
            AutoSize = true,
            Location = new Point(120, 20)
        };

        var lblSub = new Label
        {
            Text = "Select an action below:",
            Font = new Font("Segoe UI", 9),
            ForeColor = Color.Gray,
            AutoSize = true,
            Location = new Point(140, 55)
        };

        btnAddEvent = MakeButton("Add Event", new Point(60, 90));
        btnViewEvent = MakeButton("View Event", new Point(220, 90));
        btnEditEvent = MakeButton("Edit Event", new Point(60, 160));
        btnDeleteEvent = MakeButton("Delete Event", new Point(220, 160));
        btnViewByMonth = MakeButton("View by Month", new Point(60, 230));
        btnCoordinateMeeting = MakeButton("Coordinate Meeting", new Point(185, 230));
        btnCoordinateMeeting.Width = 155;

        btnAddEvent.Click += btnAddEvent_Click;
        btnViewEvent.Click += btnViewEvent_Click;
        btnEditEvent.Click += btnEditEvent_Click;
        btnDeleteEvent.Click += btnDeleteEvent_Click;
        btnViewByMonth.Click += btnViewByMonth_Click;
        btnCoordinateMeeting.Click += btnCoordinateMeeting_Click;

        this.Controls.AddRange(new Control[] {
            lblTitle, lblSub,
            btnAddEvent, btnViewEvent,
            btnEditEvent, btnDeleteEvent,
            btnViewByMonth, btnCoordinateMeeting
        });
    }

    private Button MakeButton(string text, Point location)
    {
        return new Button
        {
            Text = text,
            Location = location,
            Size = new Size(130, 50),
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            BackColor = Color.FromArgb(0, 70, 127),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
    }

    private Button btnAddEvent, btnViewEvent, btnEditEvent,
                   btnDeleteEvent, btnViewByMonth, btnCoordinateMeeting;
}
