namespace EventScheduler;

public class Manager
{
    public int Id { get; set; }
}
