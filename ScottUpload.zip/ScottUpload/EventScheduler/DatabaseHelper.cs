using MySql.Data.MySqlClient;

namespace EventScheduler;

public static class DatabaseHelper
{
    // Update this connection string to match your MySQL setup
    private static readonly string ConnectionString =
        "Server=127.0.0.1;Port=3306;Database=eventscheduler;Uid=root;Pwd=YOUR_PASSWORD_HERE;";

    public static MySqlConnection GetConnection()
    {
        return new MySqlConnection(ConnectionString);
    }

    public static bool TestConnection()
    {
        try
        {
            using var conn = GetConnection();
            conn.Open();
            return true;
        }
        catch
        {
            return false;
        }
    }
}
