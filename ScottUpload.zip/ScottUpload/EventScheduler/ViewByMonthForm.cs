using MySql.Data.MySqlClient;

namespace EventScheduler;

public partial class ViewByMonthForm : Form
{
    private DateTime _currentMonth;
    private List<(int day, string title, int eventId)> _events = new();

    public ViewByMonthForm()
    {
        InitializeComponent();
        _currentMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
        LoadAndDraw();
    }

    private void btnPrev_Click(object sender, EventArgs e)
    {
        _currentMonth = _currentMonth.AddMonths(-1);
        LoadAndDraw();
    }

    private void btnNext_Click(object sender, EventArgs e)
    {
        _currentMonth = _currentMonth.AddMonths(1);
        LoadAndDraw();
    }

    private void LoadAndDraw()
    {
        lblMonthYear.Text = _currentMonth.ToString("MMMM yyyy");
        _events.Clear();

        try
        {
            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            string sql = "SELECT eventID, title, startTime FROM Event WHERE MONTH(startTime)=@m AND YEAR(startTime)=@y ORDER BY startTime";
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@m", _currentMonth.Month);
            cmd.Parameters.AddWithValue("@y", _currentMonth.Year);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                _events.Add((Convert.ToDateTime(r["startTime"]).Day, r["title"].ToString()!, Convert.ToInt32(r["eventID"])));
        }
        catch { }

        DrawCalendar();
    }

    private void DrawCalendar()
    {
        calendarPanel.Controls.Clear();

        string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
        int cellW = 75, cellH = 50, headerH = 24;
        int cols = 7;

        // Day headers
        for (int i = 0; i < 7; i++)
        {
            var hdr = new Label
            {
                Text = days[i],
                Location = new Point(i * cellW, 0),
                Size = new Size(cellW, headerH),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(30, 50, 100),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                BorderStyle = BorderStyle.FixedSingle
            };
            calendarPanel.Controls.Add(hdr);
        }

        int startDow = (int)_currentMonth.DayOfWeek;
        int daysInMonth = DateTime.DaysInMonth(_currentMonth.Year, _currentMonth.Month);
        int day = 1;

        for (int row = 0; row < 6 && day <= daysInMonth; row++)
        {
            for (int col = 0; col < 7 && day <= daysInMonth; col++)
            {
                if (row == 0 && col < startDow) continue;

                int x = col * cellW, y = headerH + row * cellH;
                int currentDay = day;

                var cell = new Panel
                {
                    Location = new Point(x, y),
                    Size = new Size(cellW, cellH),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = Color.White,
                    Tag = currentDay
                };

                var dayNum = new Label
                {
                    Text = currentDay.ToString(),
                    Location = new Point(2, 2),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 8)
                };
                cell.Controls.Add(dayNum);

                // Add events for this day
                var dayEvents = _events.Where(e => e.day == currentDay).ToList();
                int ey = 16;
                foreach (var evt in dayEvents.Take(2))
                {
                    int eid = evt.eventId;
                    var evtLbl = new Label
                    {
                        Text = evt.title.Length > 9 ? evt.title[..9] : evt.title,
                        Location = new Point(2, ey),
                        Size = new Size(cellW - 6, 14),
                        BackColor = Color.FromArgb(30, 50, 180),
                        ForeColor = Color.White,
                        Font = new Font("Segoe UI", 7),
                        TextAlign = ContentAlignment.MiddleLeft,
                        Cursor = Cursors.Hand,
                        Tag = eid
                    };
                    evtLbl.Click += (s, e) =>
                    {
                        if (s is Label l && l.Tag is int id)
                            new ViewEventForm(id).ShowDialog();
                    };
                    cell.Controls.Add(evtLbl);
                    ey += 16;
                }

                calendarPanel.Controls.Add(cell);
                day++;
            }
        }
    }
}
