using MySql.Data.MySqlClient;

namespace EventScheduler;

public partial class AddEventForm : Form
{
    public AddEventForm() { InitializeComponent(); }

    private void btnSave_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtTitle.Text))
        { MessageBox.Show("Title is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

        var start = dtpStartDate.Value.Date + dtpStartTime.Value.TimeOfDay;
        var end = dtpEndDate.Value.Date + dtpEndTime.Value.TimeOfDay;
        if (end <= start)
        { MessageBox.Show("End must be after Start.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

        try
        {
            int duration = (int)(end - start).TotalMinutes;
            int attendees = int.TryParse(txtAttendees.Text, out int a) ? a : 0;

            using var conn = DatabaseHelper.GetConnection();
            conn.Open();
            string sql = @"INSERT INTO Event (title,description,startTime,endTime,duration,location,attendees)
                           VALUES (@t,@d,@s,@e,@dur,@l,@a)";
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@t", txtTitle.Text.Trim());
            cmd.Parameters.AddWithValue("@d", txtDescription.Text.Trim());
            cmd.Parameters.AddWithValue("@s", start);
            cmd.Parameters.AddWithValue("@e", end);
            cmd.Parameters.AddWithValue("@dur", duration);
            cmd.Parameters.AddWithValue("@l", txtLocation.Text.Trim());
            cmd.Parameters.AddWithValue("@a", attendees);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Event saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
        catch (Exception ex)
        { MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void btnCancel_Click(object sender, EventArgs e) => this.Close();
}
