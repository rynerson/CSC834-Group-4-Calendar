namespace EventScheduler;

public class Event
{
    public int EventID { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public int Duration { get; set; } // in minutes
    public string Location { get; set; } = string.Empty;
    public int Attendees { get; set; }
    public int? AttendeeID { get; set; }

    public void CalculateDuration()
    {
        Duration = (int)(EndTime - StartTime).TotalMinutes;
    }
}
